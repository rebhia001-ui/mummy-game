#ifndef HEADER_H
#define HEADER_H

#include <SDL2/SDL.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define SCREEN_W 960
#define SCREEN_H 640
#define MAX_ENEMIES 6
#define MAX_ITEMS 4

typedef enum {
    ITEM_SCORE = 0,
    ITEM_LIFE
} ItemType;

typedef enum {
    ENEMY_VIVANT = 0,
    ENEMY_BLESSE,
    ENEMY_NEUTRALISE
} EnemyHealthState;

typedef enum {
    ENEMY_ANIM_MOVE = 0,
    ENEMY_ANIM_ATTACK
} EnemyAnimState;

typedef struct {
    SDL_Rect box;
    float x;
    float y;
    float vx;
    float vy;
    int active;
    int level;
    int hp;
    int hpMax;
    EnemyHealthState healthState;
    EnemyAnimState animState;
    int animFrame;
    int animTimer;
    int attackCooldown;
    int hurtTimer;
    int dirChangeTimer;
    int minX;
    int maxX;
    int minY;
    int maxY;
    int scoreValue;
} Enemy;

typedef struct {
    ItemType type;
    SDL_Rect box;
    float x;
    float y;
    int active;
    int value;
    int bobTimer;
} Item;

typedef struct {
    SDL_Rect box;
    float x;
    float y;
    int speed;
    int facing;
    int hp;
    int hpMax;
    int attackTimer;
    int invulnTimer;
} Player;

typedef struct {
    Player player;
    Enemy enemies[MAX_ENEMIES];
    int enemyCount;
    Item items[MAX_ITEMS];
    int itemCount;
    int score;
    int level;
    int running;
} Game;

int  CheckBBCollision(const SDL_Rect* a, const SDL_Rect* b);
void Game_Init(Game* g);
void Game_HandleEvent(Game* g, SDL_Event* e);
void Game_Update(Game* g);
void Game_Render(Game* g, SDL_Renderer* ren);

#endif
