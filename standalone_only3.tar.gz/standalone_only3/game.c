#include "header.h"

static int absInt(int v)
{
    return (v < 0) ? -v : v;
}

static void SyncPlayerBox(Player* p)
{
    p->box.x = (int)p->x;
    p->box.y = (int)p->y;
}

static void SyncEnemyBox(Enemy* e)
{
    e->box.x = (int)e->x;
    e->box.y = (int)e->y;
}

int CheckBBCollision(const SDL_Rect* a, const SDL_Rect* b)
{
    if (!a || !b) return 0;

    return (a->x < b->x + b->w) &&
           (a->x + a->w > b->x) &&
           (a->y < b->y + b->h) &&
           (a->y + a->h > b->y);
}

static void UpdateEnemyHealthState(Enemy* e)
{
    if (e->hp <= 0)
        e->healthState = ENEMY_NEUTRALISE;
    else if (e->hp <= e->hpMax / 2)
        e->healthState = ENEMY_BLESSE;
    else
        e->healthState = ENEMY_VIVANT;
}

static void ChooseRandomDirection(Enemy* e)
{
    static const int dirs[8][2] = {
        {  2,  0 }, { -2,  0 },
        {  0,  2 }, {  0, -2 },
        {  2,  2 }, { -2,  2 },
        {  2, -2 }, { -2, -2 }
    };

    int idx = rand() % 8;
    e->vx = (float)dirs[idx][0];
    e->vy = (float)dirs[idx][1];
}

static void InitEnemy(Enemy* e, int x, int y, int w, int h, int level)
{
    e->box = (SDL_Rect){ x, y, w, h };
    e->x = (float)x;
    e->y = (float)y;
    e->vx = 2.0f;
    e->vy = 0.0f;
    e->active = 1;
    e->level = level;
    e->hpMax = 100;
    e->hp = 100;
    e->healthState = ENEMY_VIVANT;
    e->animState = ENEMY_ANIM_MOVE;
    e->animFrame = 0;
    e->animTimer = 0;
    e->attackCooldown = 0;
    e->hurtTimer = 0;
    e->dirChangeTimer = 60 + rand() % 100;
    e->minX = 20;
    e->maxX = SCREEN_W - w - 20;
    e->minY = 90;
    e->maxY = SCREEN_H - h - 20;
    e->scoreValue = 100;

    if (level == 1) {
        e->vx = (rand() % 2 == 0) ? 2.0f : 3.0f;
        e->vy = 0.0f;
    } else {
        ChooseRandomDirection(e);
    }
}

static void InitItem(Item* it, int x, int y, int w, int h, ItemType type, int value)
{
    it->type = type;
    it->box = (SDL_Rect){ x, y, w, h };
    it->x = (float)x;
    it->y = (float)y;
    it->active = 1;
    it->value = value;
    it->bobTimer = rand() % 20;
}

static void LoadLevel1(Game* g)
{
    g->enemyCount = 3;
    g->itemCount = 2;

    InitEnemy(&g->enemies[0], 220, 170, 42, 54, 1);
    g->enemies[0].minX = 150;
    g->enemies[0].maxX = 380;

    InitEnemy(&g->enemies[1], 430, 300, 42, 54, 1);
    g->enemies[1].minX = 360;
    g->enemies[1].maxX = 680;

    InitEnemy(&g->enemies[2], 180, 450, 42, 54, 1);
    g->enemies[2].minX = 90;
    g->enemies[2].maxX = 320;

    InitItem(&g->items[0], 700, 150, 32, 32, ITEM_SCORE, 50);
    InitItem(&g->items[1], 720, 500, 32, 32, ITEM_LIFE, 20);
}

static void LoadLevel2(Game* g)
{
    g->enemyCount = 4;
    g->itemCount = 3;

    InitEnemy(&g->enemies[0], 240, 120, 42, 54, 2);
    InitEnemy(&g->enemies[1], 600, 140, 42, 54, 2);
    InitEnemy(&g->enemies[2], 280, 360, 42, 54, 2);
    InitEnemy(&g->enemies[3], 640, 430, 42, 54, 2);

    InitItem(&g->items[0], 80, 120, 32, 32, ITEM_SCORE, 80);
    InitItem(&g->items[1], 820, 320, 32, 32, ITEM_SCORE, 100);
    InitItem(&g->items[2], 90, 520, 32, 32, ITEM_LIFE, 25);
}

static void ResetAndLoadLevel(Game* g, int level)
{
    int i;

    memset(g->enemies, 0, sizeof(g->enemies));
    memset(g->items, 0, sizeof(g->items));

    g->player.x = 60.0f;
    g->player.y = 250.0f;
    g->player.box = (SDL_Rect){ 60, 250, 40, 58 };
    g->player.speed = 4;
    g->player.facing = 1;
    g->player.attackTimer = 0;
    g->player.invulnTimer = 0;

    if (g->player.hp <= 0 || g->player.hp > g->player.hpMax)
        g->player.hp = g->player.hpMax;

    g->level = (level == 2) ? 2 : 1;

    for (i = 0; i < MAX_ENEMIES; i++)
        UpdateEnemyHealthState(&g->enemies[i]);

    if (g->level == 1)
        LoadLevel1(g);
    else
        LoadLevel2(g);
}

void Game_Init(Game* g)
{
    memset(g, 0, sizeof(*g));
    srand((unsigned int)time(NULL));

    g->running = 1;
    g->score = 0;
    g->level = 1;

    g->player.hpMax = 100;
    g->player.hp = 100;

    ResetAndLoadLevel(g, 1);
}

void Game_HandleEvent(Game* g, SDL_Event* e)
{
    if (e->type == SDL_QUIT) {
        g->running = 0;
        return;
    }

    if (e->type == SDL_KEYDOWN)
    {
        SDL_Keycode key = e->key.keysym.sym;

        if (key == SDLK_ESCAPE) {
            g->running = 0;
            return;
        }

        if (key == SDLK_1) {
            ResetAndLoadLevel(g, 1);
            return;
        }

        if (key == SDLK_2) {
            ResetAndLoadLevel(g, 2);
            return;
        }

        if (key == SDLK_r) {
            g->score = 0;
            g->player.hp = g->player.hpMax;
            ResetAndLoadLevel(g, g->level);
            return;
        }

        if (key == SDLK_SPACE) {
            if (g->player.attackTimer <= 0)
                g->player.attackTimer = 12;
        }
    }
}

static void UpdatePlayer(Game* g)
{
    const Uint8* keys = SDL_GetKeyboardState(NULL);

    if (g->player.hp <= 0)
        return;

    if (keys[SDL_SCANCODE_LEFT] || keys[SDL_SCANCODE_A] || keys[SDL_SCANCODE_Q]) {
        g->player.x -= (float)g->player.speed;
        g->player.facing = -1;
    }
    if (keys[SDL_SCANCODE_RIGHT] || keys[SDL_SCANCODE_D]) {
        g->player.x += (float)g->player.speed;
        g->player.facing = 1;
    }
    if (keys[SDL_SCANCODE_UP] || keys[SDL_SCANCODE_W] || keys[SDL_SCANCODE_Z])
        g->player.y -= (float)g->player.speed;
    if (keys[SDL_SCANCODE_DOWN] || keys[SDL_SCANCODE_S])
        g->player.y += (float)g->player.speed;

    if (g->player.x < 0.0f) g->player.x = 0.0f;
    if (g->player.y < 80.0f) g->player.y = 80.0f;
    if (g->player.x > (float)(SCREEN_W - g->player.box.w))
        g->player.x = (float)(SCREEN_W - g->player.box.w);
    if (g->player.y > (float)(SCREEN_H - g->player.box.h))
        g->player.y = (float)(SCREEN_H - g->player.box.h);

    SyncPlayerBox(&g->player);
}

static SDL_Rect GetAttackBox(const Game* g)
{
    SDL_Rect hitbox;
    hitbox.y = g->player.box.y + 10;
    hitbox.w = 26;
    hitbox.h = 18;

    if (g->player.facing > 0)
        hitbox.x = g->player.box.x + g->player.box.w + 4;
    else
        hitbox.x = g->player.box.x - hitbox.w - 4;

    return hitbox;
}

static void UpdateEnemies(Game* g)
{
    int i;

    for (i = 0; i < g->enemyCount; i++)
    {
        Enemy* e = &g->enemies[i];
        int dx;
        int dy;

        if (!e->active) continue;
        if (e->attackCooldown > 0) e->attackCooldown--;
        if (e->hurtTimer > 0) e->hurtTimer--;

        e->animTimer++;
        if (e->animTimer >= 10) {
            e->animTimer = 0;
            e->animFrame = (e->animFrame + 1) % 2;
        }

        if (e->healthState == ENEMY_NEUTRALISE)
            continue;

        dx = (g->player.box.x + g->player.box.w / 2) - (e->box.x + e->box.w / 2);
        dy = (g->player.box.y + g->player.box.h / 2) - (e->box.y + e->box.h / 2);

        if (absInt(dx) < 90 && absInt(dy) < 70)
            e->animState = ENEMY_ANIM_ATTACK;
        else
            e->animState = ENEMY_ANIM_MOVE;

        if (e->level == 1)
        {
            e->x += e->vx;

            if (e->x <= e->minX) {
                e->x = (float)e->minX;
                e->vx = -e->vx;
            }
            if (e->x >= e->maxX) {
                e->x = (float)e->maxX;
                e->vx = -e->vx;
            }
        }
        else
        {
            e->x += e->vx;
            e->y += e->vy;
            e->dirChangeTimer--;

            if (e->x <= e->minX || e->x >= e->maxX)
                e->vx = -e->vx;
            if (e->y <= e->minY || e->y >= e->maxY)
                e->vy = -e->vy;

            if (e->x < e->minX) e->x = (float)e->minX;
            if (e->x > e->maxX) e->x = (float)e->maxX;
            if (e->y < e->minY) e->y = (float)e->minY;
            if (e->y > e->maxY) e->y = (float)e->maxY;

            if (e->dirChangeTimer <= 0) {
                ChooseRandomDirection(e);
                e->dirChangeTimer = 50 + rand() % 110;
            }
        }

        SyncEnemyBox(e);
    }
}

static void UpdateItems(Game* g)
{
    int i;

    for (i = 0; i < g->itemCount; i++)
    {
        if (!g->items[i].active) continue;
        g->items[i].bobTimer = (g->items[i].bobTimer + 1) % 20;
        g->items[i].box.x = (int)g->items[i].x;
        g->items[i].box.y = (int)g->items[i].y + (g->items[i].bobTimer < 10 ? -2 : 2);
    }
}

static void HandleEnemyCollisions(Game* g)
{
    int i;
    SDL_Rect attackBox = GetAttackBox(g);

    for (i = 0; i < g->enemyCount; i++)
    {
        Enemy* e = &g->enemies[i];

        if (!e->active) continue;
        if (e->healthState == ENEMY_NEUTRALISE) continue;

        /* 1) meme fonction BB pour joueur / ennemi */
        if (CheckBBCollision(&g->player.box, &e->box))
        {
            e->animState = ENEMY_ANIM_ATTACK;

            if (e->attackCooldown <= 0 && g->player.invulnTimer <= 0)
            {
                g->player.hp -= 10;
                if (g->player.hp < 0)
                    g->player.hp = 0;

                g->player.invulnTimer = 25;
                e->attackCooldown = 35;
            }
        }

        if (g->player.attackTimer > 0 && CheckBBCollision(&attackBox, &e->box))
        {
            e->hp -= 34;
            if (e->hp < 0)
                e->hp = 0;

            e->hurtTimer = 14;
            UpdateEnemyHealthState(e);

            if (e->healthState == ENEMY_NEUTRALISE)
                g->score += e->scoreValue;
        }
    }
}

static void HandleItemCollisions(Game* g)
{
    int i;

    for (i = 0; i < g->itemCount; i++)
    {
        Item* it = &g->items[i];

        if (!it->active) continue;

        /* 2) meme fonction BB pour joueur / ES */
        if (CheckBBCollision(&g->player.box, &it->box))
        {
            if (it->type == ITEM_SCORE)
                g->score += it->value;
            else {
                g->player.hp += it->value;
                if (g->player.hp > g->player.hpMax)
                    g->player.hp = g->player.hpMax;
            }

            it->active = 0;
        }
    }
}

static int CountAliveEnemies(const Game* g)
{
    int i;
    int alive = 0;

    for (i = 0; i < g->enemyCount; i++)
    {
        if (g->enemies[i].active && g->enemies[i].healthState != ENEMY_NEUTRALISE)
            alive++;
    }

    return alive;
}

void Game_Update(Game* g)
{
    if (g->player.attackTimer > 0)
        g->player.attackTimer--;
    if (g->player.invulnTimer > 0)
        g->player.invulnTimer--;

    UpdatePlayer(g);
    UpdateEnemies(g);
    UpdateItems(g);

    HandleEnemyCollisions(g);
    HandleItemCollisions(g);

    if (g->player.hp <= 0)
        g->player.hp = 0;

    if (CountAliveEnemies(g) == 0)
    {
        if (g->level == 1)
            ResetAndLoadLevel(g, 2);
        else
            ResetAndLoadLevel(g, 1);
    }
}

static void RenderBackground(Game* g, SDL_Renderer* ren)
{
    SDL_Rect ground = { 0, SCREEN_H - 80, SCREEN_W, 80 };
    SDL_Rect block1 = { 130, 220, 200, 14 };
    SDL_Rect block2 = { 430, 350, 240, 14 };
    SDL_Rect levelMark = { SCREEN_W - 40, 20, 14, 34 };

    if (g->level == 1)
        SDL_SetRenderDrawColor(ren, 35, 58, 92, 255);
    else
        SDL_SetRenderDrawColor(ren, 54, 35, 86, 255);
    SDL_RenderClear(ren);

    SDL_SetRenderDrawColor(ren, 70, 120, 72, 255);
    SDL_RenderFillRect(ren, &ground);

    SDL_SetRenderDrawColor(ren, 90, 90, 115, 255);
    SDL_RenderFillRect(ren, &block1);
    SDL_RenderFillRect(ren, &block2);

    if (g->level == 1)
        SDL_SetRenderDrawColor(ren, 120, 170, 255, 255);
    else
        SDL_SetRenderDrawColor(ren, 205, 120, 255, 255);
    SDL_RenderFillRect(ren, &levelMark);
}

static void RenderEnemyHealthBar(const Enemy* e, SDL_Renderer* ren)
{
    SDL_Rect bg;
    SDL_Rect fill;
    int fillW;

    if (!e->active) return;

    bg.x = e->box.x;
    bg.y = e->box.y - 10;
    bg.w = e->box.w;
    bg.h = 6;

    SDL_SetRenderDrawColor(ren, 20, 20, 20, 255);
    SDL_RenderFillRect(ren, &bg);

    fillW = (e->hp * e->box.w) / e->hpMax;
    if (fillW < 0) fillW = 0;

    fill.x = bg.x;
    fill.y = bg.y;
    fill.w = fillW;
    fill.h = bg.h;

    if (e->healthState == ENEMY_VIVANT)
        SDL_SetRenderDrawColor(ren, 50, 220, 90, 255);
    else if (e->healthState == ENEMY_BLESSE)
        SDL_SetRenderDrawColor(ren, 240, 180, 40, 255);
    else
        SDL_SetRenderDrawColor(ren, 170, 45, 45, 255);

    SDL_RenderFillRect(ren, &fill);
}

static void RenderEnemy(const Enemy* e, SDL_Renderer* ren)
{
    SDL_Rect body;
    SDL_Rect head;
    SDL_Rect leg1;
    SDL_Rect leg2;
    SDL_Rect arm1;
    SDL_Rect arm2;

    if (!e->active) return;

    body = e->box;
    head = (SDL_Rect){ body.x + 8, body.y - 10, body.w - 16, 12 };
    leg1 = (SDL_Rect){ body.x + 8 + (e->animFrame ? 2 : -2), body.y + body.h - 4, 8, 14 };
    leg2 = (SDL_Rect){ body.x + body.w - 16 + (e->animFrame ? -2 : 2), body.y + body.h - 4, 8, 14 };
    arm1 = (SDL_Rect){ body.x - ((e->animState == ENEMY_ANIM_ATTACK) ? 12 : 6), body.y + 18, 12, 6 };
    arm2 = (SDL_Rect){ body.x + body.w - 6, body.y + 18, (e->animState == ENEMY_ANIM_ATTACK) ? 18 : 12, 6 };

    SDL_SetRenderDrawBlendMode(ren, SDL_BLENDMODE_BLEND);

    if (e->hurtTimer > 0)
    {
        SDL_Rect blood = { body.x - 6, body.y - 6, body.w + 12, body.h + 12 };
        SDL_SetRenderDrawColor(ren, 255, 30, 30, 90);
        SDL_RenderFillRect(ren, &blood);
    }

    if (e->healthState == ENEMY_VIVANT)
        SDL_SetRenderDrawColor(ren, 170, 70, 70, 255);
    else if (e->healthState == ENEMY_BLESSE)
        SDL_SetRenderDrawColor(ren, 220, 120, 40, 255);
    else
        SDL_SetRenderDrawColor(ren, 100, 100, 100, 255);

    SDL_RenderFillRect(ren, &body);
    SDL_RenderFillRect(ren, &head);
    SDL_RenderFillRect(ren, &leg1);
    SDL_RenderFillRect(ren, &leg2);
    SDL_RenderFillRect(ren, &arm1);
    SDL_RenderFillRect(ren, &arm2);

    SDL_SetRenderDrawColor(ren, 250, 250, 250, 255);
    {
        SDL_Rect eye1 = { head.x + 4, head.y + 3, 3, 3 };
        SDL_Rect eye2 = { head.x + head.w - 7, head.y + 3, 3, 3 };
        SDL_RenderFillRect(ren, &eye1);
        SDL_RenderFillRect(ren, &eye2);
    }
}

static void RenderItem(const Item* it, SDL_Renderer* ren)
{
    if (!it->active) return;

    if (it->type == ITEM_SCORE)
    {
        SDL_SetRenderDrawColor(ren, 240, 210, 40, 255);
        SDL_RenderFillRect(ren, &it->box);
        SDL_SetRenderDrawColor(ren, 255, 255, 255, 255);
        {
            SDL_Rect center = { it->box.x + 7, it->box.y + 7, it->box.w - 14, it->box.h - 14 };
            SDL_RenderFillRect(ren, &center);
        }
    }
    else
    {
        SDL_Rect h1 = { it->box.x + 6, it->box.y + it->box.h / 2 - 3, it->box.w - 12, 6 };
        SDL_Rect h2 = { it->box.x + it->box.w / 2 - 3, it->box.y + 6, 6, it->box.h - 12 };
        SDL_SetRenderDrawColor(ren, 60, 220, 90, 255);
        SDL_RenderFillRect(ren, &h1);
        SDL_RenderFillRect(ren, &h2);
    }
}

static void RenderPlayer(const Game* g, SDL_Renderer* ren)
{
    SDL_Rect head = { g->player.box.x + 8, g->player.box.y - 10, g->player.box.w - 16, 12 };
    SDL_Rect arm  = { g->player.box.x + (g->player.facing > 0 ? g->player.box.w - 2 : -14), g->player.box.y + 18, 14, 6 };

    SDL_SetRenderDrawBlendMode(ren, SDL_BLENDMODE_BLEND);

    if (g->player.invulnTimer > 0)
        SDL_SetRenderDrawColor(ren, 80, 170, 255, 180);
    else
        SDL_SetRenderDrawColor(ren, 80, 170, 255, 255);

    SDL_RenderFillRect(ren, &g->player.box);
    SDL_RenderFillRect(ren, &head);
    SDL_RenderFillRect(ren, &arm);

    if (g->player.attackTimer > 0)
    {
        SDL_Rect sword = GetAttackBox(g);
        SDL_SetRenderDrawColor(ren, 230, 230, 230, 255);
        SDL_RenderFillRect(ren, &sword);
    }
}

static void RenderHUD(const Game* g, SDL_Renderer* ren)
{
    SDL_Rect hud = { 10, 10, 270, 56 };
    SDL_Rect hpBg = { 22, 24, 180, 12 };
    SDL_Rect hpFill = { 22, 24, (g->player.hp * 180) / g->player.hpMax, 12 };
    SDL_Rect scoreBar = { 22, 44, 80 + (g->score % 150), 8 };

    SDL_SetRenderDrawBlendMode(ren, SDL_BLENDMODE_BLEND);
    SDL_SetRenderDrawColor(ren, 0, 0, 0, 120);
    SDL_RenderFillRect(ren, &hud);

    SDL_SetRenderDrawColor(ren, 20, 20, 20, 255);
    SDL_RenderFillRect(ren, &hpBg);

    SDL_SetRenderDrawColor(ren, 50, 220, 90, 255);
    SDL_RenderFillRect(ren, &hpFill);

    SDL_SetRenderDrawColor(ren, 240, 210, 40, 255);
    SDL_RenderFillRect(ren, &scoreBar);

    if (g->player.hp <= 0)
    {
        SDL_Rect death = { 320, 250, 320, 70 };
        SDL_SetRenderDrawColor(ren, 180, 20, 20, 160);
        SDL_RenderFillRect(ren, &death);
    }
}

void Game_Render(Game* g, SDL_Renderer* ren)
{
    int i;

    RenderBackground(g, ren);

    for (i = 0; i < g->itemCount; i++)
        RenderItem(&g->items[i], ren);

    for (i = 0; i < g->enemyCount; i++) {
        RenderEnemy(&g->enemies[i], ren);
        RenderEnemyHealthBar(&g->enemies[i], ren);
    }

    RenderPlayer(g, ren);
    RenderHUD(g, ren);

    SDL_RenderPresent(ren);
}
