#include "header.h"

int main(void)
{
    SDL_Window* window;
    SDL_Renderer* renderer;
    SDL_Event event;
    Game game;

    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        fprintf(stderr, "SDL_Init error: %s\n", SDL_GetError());
        return 1;
    }

    window = SDL_CreateWindow(
        "Standalone SDL2 Enemy Demo",
        SDL_WINDOWPOS_CENTERED,
        SDL_WINDOWPOS_CENTERED,
        SCREEN_W,
        SCREEN_H,
        0
    );
    if (!window) {
        fprintf(stderr, "SDL_CreateWindow error: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }

    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if (!renderer) {
        fprintf(stderr, "SDL_CreateRenderer error: %s\n", SDL_GetError());
        SDL_DestroyWindow(window);
        SDL_Quit();
        return 1;
    }

    Game_Init(&game);

    while (game.running)
    {
        char title[256];

        while (SDL_PollEvent(&event))
            Game_HandleEvent(&game, &event);

        Game_Update(&game);
        Game_Render(&game, renderer);

        snprintf(
            title,
            sizeof(title),
            "Enemy Demo | Level %d | Score %d | Life %d | Arrows/ZQSD move | SPACE attack | 1/2 levels | R reset | ESC quit",
            game.level,
            game.score,
            game.player.hp
        );
        SDL_SetWindowTitle(window, title);

        SDL_Delay(16);
    }

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    return 0;
}
